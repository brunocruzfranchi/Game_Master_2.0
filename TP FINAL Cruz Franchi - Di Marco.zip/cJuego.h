///////////////////////////////////////////////////////////
//  cJuego.h
//  Implementation of the Class cJuego
//  Created on:      01-Jun.-2018 2:57:07 p. m.
//  Original author: Alumnos
///////////////////////////////////////////////////////////

#if !defined(EA_25249AF9_B8BF_441f_95EC_C0B1C8876E76__INCLUDED_)
#define EA_25249AF9_B8BF_441f_95EC_C0B1C8876E76__INCLUDED_

#include "cJugador.h"
#include "cListaT.h"
#include <string>

using namespace std;

class cJuego : public cListaT<class T>
{

public:
	///Atributos
	int Rondas;
	cJugador* Jugador_de_turno;

	///Const y Dest
	cJuego();
	virtual ~cJuego();

	///Metodos
		//Crear
		void CrearJugadores(int n = 2);								
		void CrearPaises(cListaT<cPais> *listapaises);	

		//Inicio Juego
		int Jugar();
		void Iniciar_Partida();
		void AsignarPaises(cJugador Jug);							
		void AsignarTropas(cJugador Jug);	
		
		//getters
		int getRondas();	
		cJugador* getJugador_de_turno() { return Jugador_de_turno; }
		
		//setters	
		void setJugador_de_turno(cJugador* j) {
		if (j->getN_Jugador() == 0 || j->getN_Jugador() == 1){
			Jugador_de_turno = j;
			}
		}

		//Extras
		void CambiarPais(cPais* pais, cJugador* ganador);
		void CambiarTurno(cJugador **Jugador, int k);
		void ImprimirGanador();



};
#endif // !defined(EA_25249AF9_B8BF_441f_95EC_C0B1C8876E76__INCLUDED_)
