///////////////////////////////////////////////////////////
//  cCaballeros.h
//  Implementation of the Class cCaballeros
//  Created on:      01-Jun.-2018 2:57:07 p. m.
//  Original author: Alumnos
///////////////////////////////////////////////////////////

#if !defined(EA_D1A310EB_FD53_491b_82BB_23005E2C328D__INCLUDED_)
#define EA_D1A310EB_FD53_491b_82BB_23005E2C328D__INCLUDED_

#include "cUnidades.h"

class cCaballeros : public cUnidades
{

public:
	///Const. y Dest.
	cCaballeros(int at, int hp, string tipo);
	virtual ~cCaballeros();

};
#endif // !defined(EA_D1A310EB_FD53_491b_82BB_23005E2C328D__INCLUDED_)
