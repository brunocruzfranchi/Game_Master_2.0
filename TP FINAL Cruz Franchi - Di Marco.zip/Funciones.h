#include <string>
#include <iostream>
#include <ctime>
#include "cJuego.h"
#include "cJugador.h"
#define N_PAISES_TOTALES 12

void Generar_Paises(cListaT<cPais>* paises);
