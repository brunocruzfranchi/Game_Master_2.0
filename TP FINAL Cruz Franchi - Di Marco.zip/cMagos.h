///////////////////////////////////////////////////////////
//  cMagos.h
//  Implementation of the Class cMagos
//  Created on:      01-Jun.-2018 2:57:07 p. m.
//  Original author: Alumnos
///////////////////////////////////////////////////////////

#if !defined(EA_DE5B91F6_445E_4fc9_B196_6D5E1D8C9875__INCLUDED_)
#define EA_DE5B91F6_445E_4fc9_B196_6D5E1D8C9875__INCLUDED_

#include "cUnidades.h"

class cMagos : public cUnidades
{
public:

	///Const. y Dest.
	cMagos(int at, int hp, string tipo);
	virtual ~cMagos();

};
#endif // !defined(EA_DE5B91F6_445E_4fc9_B196_6D5E1D8C9875__INCLUDED_)
